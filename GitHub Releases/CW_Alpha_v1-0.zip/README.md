# CIVILWARS - Work in Progress Civilization Game

CivilWars is a <ins>text-based, civilization developer browser game</ins> which
extends this experience to the next level.
Discover, explore, conquer, upgrade, build... Everything you need is here!

<b>The project is currently in ALPHA STAGE! If you want to help my work, contact me on email!</b>

## Current features (Alpha v1.0 - as of 14/11/2024):
1. Building/ugrading (current max level: 5)
2. Collecting resources
3. Product/hour (only counts if window's opened, elapsed time save/resume)
4. Actions log to see what happened (currently resets after reloading the page).

So far, this is what it does.
I hope once the project wil launch. Now, it's only a hobby project.

I accept any types of help. Contacts are in my profile.